// app.js
const express = require('express');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const routes = require('../config/feedRoutes');
const path = require('path');
require('../config/mongo');

 


const app = express();
const PORT = process.env.PORT || 3000;



// Set EJS as the templating engine
app.set('view engine', 'ejs');

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, 'public'))); // Serve static files

// Routes
app.use(routes);

// Home route
app.get('index', (req, res) => {
    res.redirect('/feeds');
});

// Start the server
app.listen(3000, () => {
    console.log(`Server is running on http://localhost:3000`);
});


