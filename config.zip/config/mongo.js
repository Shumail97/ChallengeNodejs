const mongoose = require('mongoose');

mongoose.connect("mongodb+srv://shumailahmad97th:@cluster0.wkbmk.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
.then(() => console.log("Connected to MongoDB"))
.catch(err => console.error("Error connecting to MongoDB", err));