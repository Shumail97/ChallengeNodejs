// routes/feedRoutes.js
const express = require('express');
const router = express.Router();
const feedController = require('../controller/feedController');


// Get all feeds
router.get('/feed', feedController.getAllFeeds);

router.get('/post', feedController.getPost)

router.get('/add-feed', feedController.renderNewFeedForm);

router.get('/create-feed', feedController.createFeed);

router.get('/edit-feed/:id', feedController.renderEditFeedForm)


router.get('/edit-feed/:id', feedController.updateFeed);


// Delete a feed
router.get('/delete-feed', feedController.deleteFeed);


module.exports = router;