const mongoose = require("mongoose");
let moment = require('moment');


const feedSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        maxlength: 15,
        },
    message: {
        type: String,
        required: true,
        maxlength: 40,
        },
    createdAt: {
        type: Date,
        default: Date.now
        get: function(createdAt){
            return moment(createdAt).format('MMMM Do YYYY, h:mm:ss a');
    }}});


    module.exports = mongoose.model('feed', feedSchema);
