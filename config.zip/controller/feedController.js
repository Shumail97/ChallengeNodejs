// controllers/feedController.js
const Feed = require('../models/feed'); // Assuming you have a Feed model in models/feed.js

// Get all feeds
const getAllFeed =  (req, res) => {
   Feed
   .find()
   .then(result) => {
    res.render("index", {feedsInfo : reuslt, error : null });
   }
   .catch((error) => console.log(errpr);
   )
};

// Render new feed form
const saveFeed =  (req, res) => {
   let newFeed = new feed(req.body);
   newFeed
   .save()
   .then(() => {
    res.redirect("/feed");
    })
    .catch((error) => {
        Feed
        .find()
        .then(result) => {
            res.render("index", {feedsInfo : reuslt, error : null });
            }
            .catch((error) => console.log(error));
    });

};

// Create a new feed
const viewFeed =  (req, res) => {
    Feed
    .findById(req.params.body)
    .then(result) => {
        res.render("viewFeed", {feedInfo : result, error : null });
        }
        .catch((error) => console.log(error));
    };


// Create a new feed
const deleteFeed =  (req, res) => {
    Feed
    .findByIdAndDelete(req.params.body)
    .then(() => {
        res.redirect("/feed");
        })
        .catch((error) => console.log(error));
    };





// Render edit feed form
const EditFeed =  (req, res) => {
    Feed
     .findById(req.params.feedId)
     .then((result)=> {res.redirect("editFeed", {feedsInfo: result})}
     .catch((error) => console.log(error));
     )};

     

// Update a feed
const updateFeed =  (req, res) => {
    Feed
    .findByIdAndUpdate(req.params.feedId, req.body)
    .then(() => {
        res.redirect("/feed");
        })


};


module.exports = {
    getAllFeed,
    saveFeed,
    viewFeed,
    EditFeed,
    updateFeed,
    deleteFeed,

};